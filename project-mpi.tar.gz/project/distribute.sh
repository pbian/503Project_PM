#!/bin/sh

for n in node01 node02 node03 node04; do
  ssh $n rm -rf project
  scp -r ~/project $n:
done

