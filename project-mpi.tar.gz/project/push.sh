git pull
git add .
git add -u
git commit -m 'my commit'
git push