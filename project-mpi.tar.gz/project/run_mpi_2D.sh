mpirun --hostfile hosts -np 5 particles_parallel_mpi
